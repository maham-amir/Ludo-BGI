#include "Box.h"
#include"Position.h"

Box::Box(int bn,bool isSafe):position(bn) , isSafeSpot(isSafe)
{

}
