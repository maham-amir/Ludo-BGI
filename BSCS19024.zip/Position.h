#pragma once

struct Position
{
	int boxnum;
public:
	Position(int bn = 0);
	
	~Position();
};
