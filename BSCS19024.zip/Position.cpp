#include "Position.h"

Position::Position(int bn) :boxnum(bn)
{

}
Position::~Position()
{

}
